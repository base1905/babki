<html>
<head>
<title>WWW.BTK-LEGEND.COM - STB</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style1 {font-family: sans-serif;}
A {text-decoration: none;}
.style2 {color: #000000}
-->
</style>
</head>

<body topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" bgcolor=#FFCC00>

<?php include '../menu3.php'; ?>

<br>

<table width="540" border="0" cellspacing="0" cellpadding="0">
  <tr> <th align="center" scope="col"><span class="style1">STB</span></th></tr>
</table>

<table cellspacing="35" cellpadding="5" border="0">
  
    
    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/stb18.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb18.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/stb19.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb19.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/ames3.jpg"><img src="http://www.btk-legend.com/styles/stb/s_ames3.jpg" border="0"></a></td>             
    </tr>
    
    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/ames4.jpg"><img src="http://www.btk-legend.com/styles/stb/s_ames4.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/ames5.jpg"><img src="http://www.btk-legend.com/styles/stb/s_ames5.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/ames6.jpg"><img src="http://www.btk-legend.com/styles/stb/s_ames6.jpg" border="0"></a></td>             
    </tr>
    
    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/ames1.jpg"><img src="http://www.btk-legend.com/styles/stb/s_ames1.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/ames2.jpg"><img src="http://www.btk-legend.com/styles/stb/s_ames2.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/seven2.jpg"><img src="http://www.btk-legend.com/styles/stb/s_seven2.jpg" border="0"></a></td>             
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/stb16.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb16.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark15.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark15.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/stb13.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb13.jpg" border="0"></a></td>             
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/stb14.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb14.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/seven1.jpg"><img src="http://www.btk-legend.com/styles/stb/s_seven1.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark17.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark17.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/stb15.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb15.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark14.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark14.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark19.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark19.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/ames7.jpg"><img src="http://www.btk-legend.com/styles/stb/s_ames7.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/stb17.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb17.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark22.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark22.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark23.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark23.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/stb10.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb10.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/stb11.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb11.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/stb3.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb3.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/stb4.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb4.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/stb5.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb5.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/stb6.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb6.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark21.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark21.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark20.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark20.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/stb9.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb9.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/stb1.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb1.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark16.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark16.jpg" border="0"></a></td>       
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/stb12.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb12.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark1.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark1.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark2.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark2.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/stb8.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb8.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark4.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark4.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark5.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark5.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark6.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark6.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/stb7.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb7.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark8.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark8.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark9.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark9.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark10.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark10.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon13.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon13.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark12.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark12.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark13.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark13.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/savien1.jpg"><img src="http://www.btk-legend.com/styles/stb/s_savien1.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark3.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark3.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon58.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon58.jpg" border="0"></a></td>     
      <td><a href="http://www.btk-legend.com/styles/stb/shvark7.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark7.jpg" border="0"></a></td>        
    </tr>

	<tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon29.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon29.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/stb2.jpg"><img src="http://www.btk-legend.com/styles/stb/s_stb2.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon12.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon12.jpg" border="0"></a></td>        
    </tr>

	<tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon25.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon25.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon38.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon38.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon27.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon27.jpg" border="0"></a></td>        
    </tr>

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon31.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon31.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon32.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon32.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon33.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon33.jpg" border="0"></a></td>        
    </tr>	
	
	<tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon34.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon34.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon4.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon4.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon36.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon36.jpg" border="0"></a></td>        
    </tr>	
	
	<tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/btkseven.jpg"><img src="http://www.btk-legend.com/styles/stb/s_btkseven.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon56.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon56.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon42.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon42.jpg" border="0"></a></td>        
    </tr>	

    <tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon46.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon46.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon55.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon55.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon48.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon48.jpg" border="0"></a></td>        
    </tr>	
	
	<tr align="center">      
      <td><a href="http://www.btk-legend.com/styles/stb/zakon49.jpg"><img src="http://www.btk-legend.com/styles/stb/s_zakon49.jpg" border="0"></a></td>      
      <td><a href="http://www.btk-legend.com/styles/stb/shvark18.jpg"><img src="http://www.btk-legend.com/styles/stb/s_shvark18.jpg" border="0"></a></td> 
      <td></td>       
    </tr>	
    
</table>
</body>
</html>
